import pymysql as psql

def mysqlconnect(query):

	# to connect to the sql db

	conn = psql.connect(
		host='nola-ridc-intern-data-etl-db.cghuxbuu9n9j.us-west-2.rds.amazonaws.com',
		user='admin',
		password='Th3N3w&vengers',
		db='nolaridc',
		)

	cur = conn.cursor()
	cur.execute(query)
	output = cur.fetchall()
	# print(output)

	# close the connection
	conn.close()

	return output

# driver code
if __name__ == "__main__":
	output = mysqlconnect("SELECT DISTINCT employee_id, workers_skill FROM nolaridc.skills LIMIT 1000");
	print(output)