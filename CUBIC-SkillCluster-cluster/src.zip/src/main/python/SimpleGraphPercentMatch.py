import DatabaseConnect as dbc
import GenerateGraph as gg
import networkx as nx
from ast import literal_eval as makeTuple
from numpy import exp
import matplotlib.pyplot as plt

createNewGraph = False

# find the clustering coefficient for a particular node 
# def localClusteringCoefficient(graph, v):

# 	# find the neighbors of v (the node being examined)
# 	N = findNeighbors(v)

def normalize(large, selection):

	return selection / large

def logistic(x):

	return (1 / (1 + exp(-10*(x - 0.4))))
	# return exp(x)

########
# MAIN #
########

if __name__ == "__main__":

	# if a new graph is required
	if createNewGraph:
		# queries 
		limit = 100;
		pairs = dbc.mysqlconnect(f"SELECT DISTINCT employee_id, workers_skill FROM nolaridc.skills WHERE employee_id IN (SELECT employee_id FROM (SELECT DISTINCT employee_id FROM nolaridc.employees LIMIT {limit}) x ) AND workers_skill IS NOT NULL AND NOT workers_skill = '' ORDER BY employee_id")
		EIDs = dbc.mysqlconnect(f"SELECT DISTINCT employee_id FROM nolaridc.employees LIMIT {limit}")

		sgraph = nx.Graph()

		gg.generate(sgraph, EIDs, pairs)

		gg.saveGraph(sgraph)


	# load a saved graph
	else: 

		sgraph = nx.read_gexf("graph.gexf")

		f = open("graph_features.txt", "r").readlines()

		features = []

		for i in f:
			if i != "":
				tmp = makeTuple(i)
				features.append(tmp)

		# f.close()

		print(features)

		selectedNode = "Microsoft Excel"

		print(nx.clustering(sgraph, selectedNode, "weight"))
		# print("\n" + str(nx.clustering(sgraph, weight="weight")))

		# Thought Process: 
		# Step 1: Find the neighbors of the desired skill 
		# Step 2: Use the strongest weight in the graph to determine how to scale weights 
		# Step 2.1: Maybe use strongest weight among the neighbors? 
		# Step 3: Use the scaled weight as input to a logarithmic function
		# Award partial points back based on the output of the logarithmic function to those who possess 
		# these neighboring skills 

		neighbors = nx.neighbors(sgraph, selectedNode)
		weights = nx.get_edge_attributes(sgraph, "weight")
		normalx = []
		normaly = []
		for x in neighbors:
			# xweights = []
			print(x)
			try:
				print(weights[selectedNode, x])
				# xweights.append(weights[selectedNode, x])
				tmp = normalize(features[1], weights[selectedNode, x])
				normalx.append(tmp)
			except:
				print(weights[x, selectedNode])
				# xweights.append(weights[x, selectedNode])
				tmp = normalize(features[1], weights[x, selectedNode])
				normalx.append(tmp)

			
			normaly.append(logistic(tmp))
			# print(normaly)
			# points.append((normalx, normaly))
			# pointx.append(normalx)

		plt.plot(normalx, normaly, 'bo')
		plt.show()
