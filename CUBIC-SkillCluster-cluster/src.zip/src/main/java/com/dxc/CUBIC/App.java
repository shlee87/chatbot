package com.dxc.CUBIC;

import java.sql.*;
import java.util.ArrayList;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.dxc.CUBIC.entities.Employee;
import com.dxc.CUBIC.entities.RequestDetails;

public class App implements RequestHandler<RequestDetails, ArrayList<Employee>> {

    @Override
    // entry point for the lambda function
    // requestDetails is the POJO representation of the query parameters
    public ArrayList<Employee> handleRequest(RequestDetails requestDetails, Context context) {

        // initialize the list of employees to return through the API
        ArrayList<Employee> employees = new ArrayList<>();

        try {

            // Populate the list of employees
            queryResultToEmployeeList(requestDetails, employees);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        // Return the list of employees
        return employees;
    }

    /**
     * @param requestDetails
     * @param responseDetails
     * @throws SQLException
     */
    private void queryResultToEmployeeList(RequestDetails requestDetails, ArrayList<Employee> employees)
            throws SQLException {

        // Getting the connection to the database
        Connection conn = getConnection();

        // Creating statement that holds the query and the result after executing the
        // query
        Statement stmt = conn.createStatement();

        // Create the query for the statement by passing the query parameters
        String query = executeQuery(requestDetails);
        ResultSet result = stmt.executeQuery(query);

        // Loop for all the records in the result
        while (result.next()) {

            // add a new employee to the employee list
            // by constructing a new employee from the information obtained from the
            // resultset
            employees.add(new Employee(
                    result.getString("EID"),
                    result.getString("Fname"),
                    result.getString("Lname"),
                    result.getString("job_title"),
                    result.getString("job_level"),
                    result.getString("Skills"),
                    result.getString("roll_off")));
        }
    }

    /**
     * @param request
     * @return
     */
    private String executeQuery(RequestDetails request) {

        //initial query string
        String query = "SELECT distinct EID, Fname, Lname, job_title, job_level, Skills, roll_off FROM "
                + " new_table JOIN SKILL_TABLE ON EID = EmployeeID WHERE job_level BETWEEN ";

        //check if the request has any parameters
        if (request != null) {

            //1 job level lower than the search criteria
            int job_level = request.getJobLevel() - 1;
            query = query.concat(job_level + " AND " + request.getJobLevel() + " AND job_title LIKE");
            
            //add the job title into the query
            query = query.concat("'%" + request.getJobTitle() + "%'  AND Skill IN (");
            
            String skills = request.getSkill();
            //split the required skills separated by a comma and add to the query
            String[] skill = skills.split(",");

            for (int i = 0; i < skill.length; i++) {
                query = query.concat("'" + skill[i] + "',");
            }
            query = query.substring(0, query.length() - 1);
            
            //group the rows and count the number of skills for each employee
            query = query.concat(") GROUP BY EID HAVING COUNT(EID) =" + skill.length + " ORDER BY job_level DESC;");
        }

        //if request has no paramters, execute only the initial query
        return query;

    }

    /**
     * @return Returns database connection
     * @throws SQLException
     */
    //create a connection to the database
    private Connection getConnection() throws SQLException {
        //Retriving values from Lambda enivironment variables
        String hostname = System.getenv("db_endpoint");
        String dbName = System.getenv("db_name");
        String dbUsername = System.getenv("username");
        String dbPassword = System.getenv("password");

        Connection conn = DriverManager.getConnection("jdbc:mysql://" + hostname +"/" + dbName, dbUsername, dbPassword);
        return conn;
    }

}
