package com.dxc.CUBIC.entities;

public class RequestDetails {
    private String skill;
    private String jobTitle;
    private int jobLevel;

    public void setSkill(String s)
    {
        skill = s;
    }
    public void setJobTitle(String j)
    {
        jobTitle = j;
    }

    public void setJobLevel(int l)
    {
        jobLevel = l;
    }

    public String getSkill()
    {
        return skill;
    }

    public String getJobTitle()
    {
        return jobTitle;
    }

    public int getJobLevel()
    {
        return jobLevel;
    }
    
}
