package com.dxc.CUBIC.entities;

public class Employee {
    private String eid;
    private String fname;
    private String lname;
    private String title;
    private String level;
    private String skills;
    private String rollOff;

    public Employee(String e, String f, String l,String t, String num, String s, String r)
    {
        eid = e;
        fname = f;
        lname =l;
        title = t;
        level = num;
        skills = s;
        rollOff = r;

    }

    public void setEid(String s)
    {
        eid = s;
    }
    public void setFname(String j)
    {
        fname = j;
    }

    public void setLname(String l)
    {
        lname = l;
    }
    public void setTitle(String t)
    {
        title = t;
    }

    public void setLevel(String l)
    {
        level = l;
    }

    public void setSkills(String s)
    {
        skills = s;
    }
    public void setRollOff(String r)
    {
        rollOff = r;
    }

    public String getEid()
    {
        return eid;
    }

    public String getFname()
    {
        return fname;
    }

    public String getLname()
    {
        return lname;
    }
    public String getTitle()
    {
        return title;
    }

    public String getLevel()
    {
        return level;
    }

    public String getSkills()
    {
        return skills;
    }
    public String getRollOff()
    {
        return rollOff;
    }
}
